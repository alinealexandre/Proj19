<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Procurso
	</title>
</head>
<body>
	<nav>
		<a href="index.php"><p>Index</p></a>
		<a href="crud_usuario.php?acao=login"><p>Login</p></a>
		<a href="crud_usuario.php?acao=signin"><p>Sign In</p></a>
	</nav>
	<hr>
</body>
</html>