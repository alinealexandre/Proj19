<!DOCTYPE html>
<html>
<head>
  <title></title>
  <script type="text/javascript" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>
  <link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  <link rel="stylesheet" type="text/css" href="css/estilo.css">
  <link rel="stylesheet" type="text/css" href="../dist/components/message.css">
  <script src="assets/library/jquery.min.js"></script>
  <script src="../dist/components/form.js"></script>
  <script src="../dist/components/transition.js"></script>
  <script type="text/javascript">

    $('.ui.dropdown')
      .dropdown();
  </script>

   <script>
  $(document)
    .ready(function() {

      // fix menu when passed
      $('.masthead')
        .visibility({
          once: false,
          onBottomPassed: function() {
            $('.fixed.menu').transition('fade in');
          },
          onBottomPassedReverse: function() {
            $('.fixed.menu').transition('fade out');
          }
        })
      ;

      // create sidebar and attach to menu open
      $('.ui.sidebar')
        .sidebar('attach events', '.toc.item')
      ;

    })
  ;
  </script>
    <script>
  $(document)
    .ready(function() {
      $('.ui.form')
        .form({
          fields: {
            email: {
              identifier  : 'email',
              rules: [
                {
                  type   : 'empty',
                  prompt : 'Coloque seu email'
                },
                {
                  type   : 'email',
                  prompt : 'Coloque um email válido'
                }
              ]
            },
            password: {
              identifier  : 'password',
              rules: [
                {
                  type   : 'empty',
                  prompt : 'Coloque sua senha'
                },
                {
                  type   : 'length[6]',
                  prompt : 'Senha invalida'
                }
              ]
            }
          }
        })
      ;
    })
  ;
  </script>

<!--
    <div class="ui secondary pointing menu huge menuzinho">
  <a class=" active item">
    Home
  </a>
  <a class="item">
    Cadastro
  </a>
  <a class="item">
    Cursos
  </a>
  <a class="item">
    Faculdades
  </a>

  <div class="center menu">
    <img class="ui centered logo" src="img/foto1.jpeg">
  </div>

  <div class="right menu">
    <a class="ui item active">
      Logout
    </a>
  </div>
</div>







<link href='http://fonts.googleapis.com/css?family=Lato:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
  
<div class="uisecondary pointing menu huge menuzinho menuu">
  <ul>
    <li><a href="#">home</a></li>
    <li><a href="###">cursos</a></li>
    <li><a href="###">Faculdades</a></li>

  </ul>
  <div class="logo"></div>

   <div class=" right menu">
    <a class="ui item active">
      Logout
    </a>
  </div>

</div> -->




<div class="menu">
    <div class="container clearfix">

      <div id="logo" class="grid_3">
        <img src="images/logo.png">
      </div>

      <div id="nav" class="grid_9 omega">
        <ul class="navigation">
          <li data-slide="1"> <a href="index.php"> Início</a></li>
          <li data-slide="2">Saúde</li>
          <li data-slide="3">Lazer</li>
            <div class="logo"></div>
          <li data-slide="4">Cuidadores</li>
          <li data-slide="5">Instituições</li>
          <li data-slide="8"><a href="###">Login</a></li>
        </ul>
      </div>

    </div>
  </div>



<img class="ui medium circular image" src="img/foto1.jpeg">

</div>
