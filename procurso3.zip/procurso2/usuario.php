<!DOCTYPE html>
<html>
<head>
  <title></title>
  <script type="text/javascript" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>
  <link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  <link rel="stylesheet" type="text/css" href="css/estilo.css">
  <link rel="stylesheet" type="text/css" href="../dist/components/message.css">
  <script src="assets/library/jquery.min.js"></script>
  <script src="../dist/components/form.js"></script>
  <script src="../dist/components/transition.js"></script>
  <script type="text/javascript">

    $('.ui.dropdown')
      .dropdown();
  </script>

   <script>
  $(document)
    .ready(function() {

      // fix menu when passed
      $('.masthead')
        .visibility({
          once: false,
          onBottomPassed: function() {
            $('.fixed.menu').transition('fade in');
          },
          onBottomPassedReverse: function() {
            $('.fixed.menu').transition('fade out');
          }
        })
      ;

      // create sidebar and attach to menu open
      $('.ui.sidebar')
        .sidebar('attach events', '.toc.item')
      ;

    })
  ;
  </script>

<!-- Page Contents -->
<div class="pusher">

    <div class="ui container cor2">
      <div class="ui large secondary inverted pointing menu cor2">
        <a class="toc item">
          <i class="sidebar icon"></i>
        </a>
        <a class="active item black">Home</a>
        <a class="item">Cadastro</a>
        <a class="item">Cursos</a>
        <a class="item inverted">Faculdades</a>
        <div class="right item">
          <a href="login.php" class="ui inverted button">Log in</a>
          <a href="cadastro.php" class="ui inverted button">Sign Up</a>
        </div>
      </div>
    </div>



<div class="espaco_perfil">
    <div class="ui centered card">
      <div class="image">
        <img src="img/foto1.jpeg">
      </div>
      <div class="content">
        <a class="header">Aline</a>
        <div class="meta">
        </div>
        <div class="description">
          
        </div>
        <div class="ui list">
            <div class="item">
              <i class="user icon"></i>
              <div class="content">
                <a class="header" id="letra">Aline Silva Sauro</a>
              </div>
            </div>
            <div class="item">
              <i class="birthday cake icon"></i>
              <div class="content">
                <a class="header" id="letra">19/04/1990</a>
              </div>
            </div>
            <div class="item">
              <i class="edit icon"></i>
              <div class="content">
                <a href="edit_usuario.php" class="header">Editar Informações</a>
              </div>
            </div>
            <div class="item">
              <i class="edit icon"></i>
              <div class="content">
                <a class="header">Excluir Conta</a>
              </div>
            </div>

        </div>
      </div>
    </div>
</div>

<div class="espaco_favoritos">

  <h1 class="ui dividing centered header">Favoritados</h1>
  <h2 class="ui dividing centered header">Cursos</h2>
    <div class="ui three column grid">
      <div class="column">
        <div class="ui fluid card ">
          <div class="image " >
             <img src="img/foto1.jpeg">
          </div>
          <div class="content">
            <a class="header">Geografia</a>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="ui fluid card">
          <div class="image">
            <img src="img/foto1.jpeg">
          </div>
          <div class="content">
            <a class="header">Ciências Sociais</a>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="ui fluid card">
          <div class="image">
            <img src="img/foto1.jpeg">
          </div>
          <div class="content">
            <a class="header">Agronomia</a>
          </div>
        </div>
      </div>
    </div>

  <h2 class="ui dividing centered header">Faculdades</h2>
    <div class="ui three column grid">
      <div class="column">
        <div class="ui fluid card">
          <div class="image">
            <img src="img/foto1.jpeg">
          </div>
          <div class="content">
            <a class="header">UFSC - Joinville</a>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="ui fluid card">
          <div class="image">
            <img src="img/foto1.jpeg">
          </div>
          <div class="content">
            <a class="header">UFFS - Chapecó</a>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="ui fluid card">
          <div class="image">
            <img src="img/foto1.jpeg">
          </div>
          <div class="content">
            <a class="header">UFSC - Florianópolis</a>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="ui fluid card">
          <div class="image">
            <img src="img/foto1.jpeg">
          </div>
          <div class="content">
            <a class="header">UFSC - Blumenau</a>
          </div>
        </div>
      </div>
    </div>



</div>
</div>
</body>

 <footer>
        <center class="footer">
      <i class="fa fa-facebook icones_footer"></i>
        <i class="fa fa-twitter icones_footer" ></i>
        <i class="fa fa-dribbble icones_footer"></i>
        </center>
</footer>

</html>



