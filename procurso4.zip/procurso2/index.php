<?php include 'cabecalho.php'?>

<!-- Page Contents -->
<div class="pusher">
<div class="ui inverted vertical masthead center aligned segment cor1" href="img\fundo.jpeg">
    <div class="ui text container">
      <h1 class="ui inverted header">
        Procurso
      </h1>
      <h2>Encontre o curso e a faculdade ideal para você.</h2>
      <div class="ui search large">
      <div class="ui icon input">
        <input class="prompt" type="text" placeholder="Pesquisar...">
        <i class="search icon "></i>
      </div>
      <div class="results"></div>
    </div>
    </div>

  </div>
</div>

<div class="barra_superior1"></div>
<div class="barra_lateral1"></div>
	<div class="ui link cards ">

	  <div class="card">
	    <div class="image">
	      <img src="img/foto1.jpeg">
	    </div>
	    <button class="ui button orange">Cursos</button>
	  </div>

	    <div class="card">
	    <div class="image">
	      <img src="img/foto1.jpeg">
	    </div>
	    <button class="ui button orange">Faculdades</button>
	  </div>

	    <div class="card">
	    <div class="image">
	      <img src="img/foto1.jpeg">
	    </div>
	    <button class="ui button orange">Sobre Nós</button>
	  </div>
	</div>


</head>
<body>




</body>
</html>

