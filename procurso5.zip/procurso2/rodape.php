 <footer class="rodape">
        <center class="">
        	<img class="ui mini circular image" src="img/foto1.jpeg">
        	<img class="ui mini circular image" src="img/foto1.jpeg">
        	<img class="ui mini circular image" src="img/foto1.jpeg">

        </center>
    </footer>