<?php include 'cabecalho.php'?>


      <div class="coluna_cad_dir"></div>
      <div class="barra_sup_login"></div>
      <div class="coluna_cad">
      <div class="coluna_cad2">

      <form class="ui form">
  <h3 class="ui dividing header">Coloque suas Informações</h3>
  <div class="field">
    <label>Nome</label>
    <div class="two fields">
      <div class="field">
        <input type="text" name="shipping[first-name]" placeholder="Primeiro Nome">
      </div>
      <div class="field">
        <input type="text" name="shipping[last-name]" placeholder="Sobrenome">
      </div>
    </div>
  </div>

  <h4 class="ui dividing header">Email</h4>
  <div class="field">
        <div class="field">
          <div class="ui input">
            <input type="text" name="email" placeholder="Seu Email">
          </div>
        </div>
  </div>
  <div class="two fields">
  </div>
  <h4 class="ui dividing header">Data de Nascimento</h4>
  <div class="fields">
    <div class="three wide field">
    </div>
    <div class="three wide field">

      <input type="text" name="card[cvc]" maxlength="3" placeholder="Dia">
    </div>
    <div class="six wide field">

      <div class="two fields">
        <div class="field">
          <select class="ui fluid search dropdown" name="card[expire-month]">
            <option value="">Mês</option>
            <option value="1">Janeiro</option>
            <option value="2">Fevereiro</option>
            <option value="3">Março</option>
            <option value="4">Abril</option>
            <option value="5">Maio</option>
            <option value="6">Junho</option>
            <option value="7">Julho</option>
            <option value="8">Agosto</option>
            <option value="9">Setembro</option>
            <option value="10">Outubro</option>
            <option value="11">Novembro</option>
            <option value="12">Dezembro</option>
          </select>
        </div>
        <div class="field">
          <input type="text" name="card[expire-year]" maxlength="4" placeholder="Ano">
        </div>
      </div>
    </div>
  </div>

   <h4 class="ui dividing header">Imagem de Perfil</h4>
        <div class="field">
          <div class="ui input">
            <input type="file" name="image" placeholder="Inserir Imagem">
          </div>
        </div>

   <h4 class="ui dividing header">Sua senha</h4>
  <div class="field">
      <div class="ui input">
        <input type="password" name="password" placeholder="Senha">
    </div>
  </div>


   <h4 class="ui dividing header">Receipt</h4>
   <div class="ui segment">
    <div class="field">
      <div class="ui toggle checkbox">
        <input type="checkbox" name="gift" tabindex="0" class="hidden">
        <label>Li e concordo com os Termos de Uso</label>
      </div>
    </div>
  </div>
  <div class="ui button" tabindex="0">Enviar</div>
</form>
</div>
</div>
