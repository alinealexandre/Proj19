<!DOCTYPE html>
<html>
<head>
  <title></title>
  <script type="text/javascript" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>
  <link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  <link rel="stylesheet" type="text/css" href="css/estilo.css">
  <link rel="stylesheet" type="text/css" href="../dist/components/message.css">
  <script src="assets/library/jquery.min.js"></script>
  <script src="../dist/components/form.js"></script>
  <script src="../dist/components/transition.js"></script>
  <script type="text/javascript">


    $('.ui.dropdown')
      .dropdown();
  </script>
<style>
body {
    background-color: #f6755e;
}
</style>
   <script>
  $(document)
    .ready(function() {

      // fix menu when passed
      $('.masthead')
        .visibility({
          once: false,
          onBottomPassed: function() {
            $('.fixed.menu').transition('fade in');
          },
          onBottomPassedReverse: function() {
            $('.fixed.menu').transition('fade out');
          }
        })
      ;

      // create sidebar and attach to menu open
      $('.ui.sidebar')
        .sidebar('attach events', '.toc.item')
      ;

    })
  ;
  </script>


<!--
<link href='http://fonts.googleapis.com/css?family=Lato:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
  
<div class="menu">
  <ul>
    <li><a href="#">home</a></li>
    <li><a href="#">products</a></li>
    <li><a href="#">contact</a></li>
    <li><a href="#">item</a></li>
    <li><a href="#">support</a></li>
    <li><a href="#">about</a></li>
  </ul>
  <div class="logo"></div>
</div>
-->


<!--
<div class="linha_menu">


 <div class="coluna1_menu">

   <a class="item">
    Home
   </a>
   <a class="item">
    Cadastro
   </a>
   <a class="item active">
    Cursos
   </a>
    <a class="item active">
    Faculdades
   </a>

  </div>
  <div class="coluna2_menu">
    <img src="###">
  </div>
  <div class="coluna3_menu"></div>


</div>
-->

<body>

                    <div class="ui secondary pointing menu menu_edit">
                      <a class="active item">
                        Home
                      </a>
                      <a class="item">
                        Cursos
                      </a>
                      <a class="item">
                        Faculdades
                      </a>

                      <div class="centered aligned menu">...</div>
                      <div class="right menu">
                        <a class="ui item">
                          Cadastrar-se
                        </a>
                        <a class="ui item">
                          Login
                        </a>
                      </div>
                    </div>

</body>