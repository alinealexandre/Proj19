<?php
include 'cabecalho.php';
?>

      <div class="coluna_cad_dir"></div>
      <div class="barra_sup_login"></div>
      <div class=" coluna_cad">
      <div class="coluna_cad2">

      <form method="post" action='controler.php?acao=cadastrar' class="ui form">
  <h3 class="ui dividing header" id="cor4">Cadastrar novo Usuário </h3>
  <div class="field">
    <label class="ui dividing header" id="cor4">Nome</label>
    <div class="two fields">
      <div class="field">
        <input type="text" name="nome" placeholder="Primeiro Nome" required>
      </div>
      <div class="field">
        <input type="text" name="sobrenome" placeholder="Sobrenome" required>
      </div>
    </div>
  </div>
  <h4 class="ui dividing header" id="cor4">Email</h4>
  <div class="field">
    <?php
if(isset($_GET['u'])){
  echo'<p class="incorreto">Email ja cadastrado</p>';
  }
?>
        <div class="field">
          <div class="ui input">
            <input type="text" name="email" placeholder="Seu Email" required>
          </div>
        </div>
  </div>
  <div class="two fields">
  </div>
  <h4 class="ui dividing header" id="cor4">Data de Nascimento</h4>
  <input type="date" name="data_nasc" required>

   <h4 class="ui dividing header" id="cor4">Imagem de Perfil</h4>
        <div class="field">
          <div class="ui input">
            <input type="file" name="image" placeholder="Inserir Imagem">
          </div>
        </div>

   <h4 class="ui dividing header" id="cor4">Sua senha</h4>
  <div class="field">
      <div class="ui input">
        <input type="password" name="password" placeholder="Senha" required>
    </div>
  </div>

  <input class="ui button orange botao_enviar" type="submit" name="">
</form>
</div>
</div>
