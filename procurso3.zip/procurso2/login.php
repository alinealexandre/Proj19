<!DOCTYPE html>
<html>
<head>
  <title></title>
  <script type="text/javascript" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>
  <link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  <link rel="stylesheet" type="text/css" href="css/estilo.css">
  <link rel="stylesheet" type="text/css" href="../dist/components/message.css">
  <script src="assets/library/jquery.min.js"></script>
  <script src="../dist/components/form.js"></script>
  <script src="../dist/components/transition.js"></script>
  <script type="text/javascript">

    $('.ui.dropdown')
      .dropdown();
  </script>

   <script>
  $(document)
    .ready(function() {

      // fix menu when passed
      $('.masthead')
        .visibility({
          once: false,
          onBottomPassed: function() {
            $('.fixed.menu').transition('fade in');
          },
          onBottomPassedReverse: function() {
            $('.fixed.menu').transition('fade out');
          }
        })
      ;

      // create sidebar and attach to menu open
      $('.ui.sidebar')
        .sidebar('attach events', '.toc.item')
      ;

    })
  ;
  </script>
    <script>
  $(document)
    .ready(function() {
      $('.ui.form')
        .form({
          fields: {
            email: {
              identifier  : 'email',
              rules: [
                {
                  type   : 'empty',
                  prompt : 'Coloque seu email'
                },
                {
                  type   : 'email',
                  prompt : 'Coloque um email válido'
                }
              ]
            },
            password: {
              identifier  : 'password',
              rules: [
                {
                  type   : 'empty',
                  prompt : 'Coloque sua senha'
                },
                {
                  type   : 'length[6]',
                  prompt : 'Senha invalida'
                }
              ]
            }
          }
        })
      ;
    })
  ;
  </script>
<nav>
<!-- Page Contents -->
<div class="pusher">

    <div class="ui container cor2">
      <div class="ui large secondary inverted pointing menu cor2">
        <a class="toc item">
          <i class="sidebar icon"></i>
        </a>
        <a class="active item black">Home</a>
        <a class="item">Cadastro</a>
        <a class="item">Cursos</a>
        <a class="item inverted">Faculdades</a>
        <div class="right item">
          <a href="login.php" class="ui inverted button">Log in</a>
          <a href="cadastro.php" class="ui inverted button">Sign Up</a>
        </div>
      </div>
    </div>
</nav>
      <div class="coluna_login_dir"></div>
      <div class="barra_sup_login"></div>
      <div class="coluna_login">
      

        <div class=" middle aligned center aligned grid barra_cima_login">
           <div class="column">
              <h2 class="ui teal image header">
               <!-- <img src="assets/images/logo.png" class="image"> -->
                 <div class="content">
                 Logue em sua conta 
                  </div>
         </h2>
       <form class="ui large form">
      <div class="ui stacked segment ">
        <div class="field">
          <div class="ui left icon input">
            <i class="user icon"></i>
            <input type="text" name="email" placeholder="Email ">
          </div>
        </div>
          <div class="field">
          <div class="ui left icon input">
            <i class="lock icon"></i>
            <input type="password" name="password" placeholder="Senha">
          </div>
        </div>
        <div href="usuario.php" class="ui fluid large teal submit button yellow"><a href="usuario.php" >Login</a></div>
      </div>
      </div>

           <!-- <div class="ui error message"></div> -->

    </form>

    <div class="ui message">
      É novo aqui? <a href="cadastro.php">Crie sua conta</a>
    </div>
  </div>

  </div>
</div>


</head>
</body>

 <?php include 'rodape.php'?>

</html>