  <?php
  include 'class.php';
  

  //$teste=new Query;
  //$teste->select('select * from usuario');
  //print_r($teste->dados);