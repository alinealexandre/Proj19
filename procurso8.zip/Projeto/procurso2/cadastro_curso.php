<?php
include 'cabecalho.php';
?>

      <div class="coluna_cad_dir"></div>
      <div class="barra_sup_login"></div>
      <div class=" coluna_cad">
      <div class="coluna_cad2">

      <form method="post" action='controler.php?acao=cadastrar' class="ui form">
  <h3 class="ui dividing header" id="cor4">Cadastrar novo Curso </h3>
  <div class="field">
    <label class="ui dividing header" id="cor4">Nome </label>
    <div class="two fields">
      <div class="field">
        <input type="text" name="nome" placeholder="Nome do Curso" required>
      </div>
    </div>
  </div>

  <h4 class="ui dividing header" id="cor4">Grau</h4>
  <div class="field">
      <div class="ui input">
        <input type="text" name="grau" placeholder="ex: Bacharelado" required>
    </div>
  </div>

  <h4 class="ui dividing header" id="cor4">Descrição</h4>
  <div class="field">

        <div class="field">
          <div class="ui input">
            <textarea rows="4"></textarea required>
          </div>
        </div>
  </div>
  <div class="two fields">
  </div>
  <h4 class="ui dividing header" id="cor4">Carga Horaria</h4>
  <input type="text" name="carga_horaria" placeholder="ex: 10 semestres" required>

   <h4 class="ui dividing header" id="cor4">Forma de Ingresso</h4>
        <div class="field">
          <div class="ui input">
            <input type="text" name="forma_ingresso" placeholder="ex: SISU" required>
          </div>
        </div>

   <h4 class="ui dividing header" id="cor4">Numero de Vagas</h4>
  <div class="field">
      <div class="ui input">
        <input type="text" name="numero_vagas" placeholder="ex: 70" required>
    </div>
  </div>

   <h4 class="ui dividing header" id="cor4">Turno</h4>
  <div class="field">
      <div class="ui input">
        <input type="text" name="turno" placeholder="ex: Matutino" required>
    </div>
  </div>

     <h4 class="ui dividing header" id="cor4">Modalidade</h4>
  <div class="field">
      <div class="ui input">
        <input type="text" name="modalidade" placeholder="ex: Presencial" required>
    </div>
  </div>

  <input class="ui button orange botao_enviar" type="submit" name="">
</form>
</div>
</div>