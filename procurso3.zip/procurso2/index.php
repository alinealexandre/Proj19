<!DOCTYPE html>
<html>
<head>
	<title></title>
  <script type="text/javascript" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>
  <link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  <link rel="stylesheet" type="text/css" href="css/estilo.css">
  <style>
	body {
	background-color: #25a2c3;
	}
</style>
  <script type="text/javascript">
    $('.ui.dropdown')
      .dropdown();
  </script>

   <script>
  $(document)
    .ready(function() {

      // fix menu when passed
      $('.masthead')
        .visibility({
          once: false,
          onBottomPassed: function() {
            $('.fixed.menu').transition('fade in');
          },
          onBottomPassedReverse: function() {
            $('.fixed.menu').transition('fade out');
          }
        })
      ;

      // create sidebar and attach to menu open
      $('.ui.sidebar')
        .sidebar('attach events', '.toc.item')
      ;

    })
  ;
  </script>

<!-- Page Contents -->
<div class="pusher">

    <div class="ui container">
      <div class="ui large secondary inverted pointing menu white barra">
        <a class="toc item">
          <i class="sidebar icon"></i>
        </a>
        <a class="active item black">Home</a>
        <a class="item">Cadastro</a>
        <a class="item">Cursos</a>
        <a class="item inverted">Faculdades</a>
        <div class="right item">
          <a href="login.php" class="ui inverted button">Login</a>
          <a class="ui inverted button">Cadastrar-se</a>
        </div>
      </div>
    </div>
<div class="ui inverted vertical masthead center aligned segment cor1" href="img\fundo.jpeg">
    <div class="ui text container">
      <h1 class="ui inverted header">
        Procurso
      </h1>
      <h2>Encontre o curso e a faculdade ideal para você.</h2>
      <div class="ui search large">
      <div class="ui icon input">
        <input class="prompt" type="text" placeholder="Pesquisar...">
        <i class="search icon "></i>
      </div>
      <div class="results"></div>
    </div>
    </div>

  </div>
</div>

<div class="barra_superior1"></div>
<div class="barra_lateral1"></div>
	<div class="ui link cards ">

	  <div class="card">
	    <div class="image">
	      <img src="img/foto1.jpeg">
	    </div>
	    <button class="ui button orange">Cursos</button>
	  </div>

	    <div class="card">
	    <div class="image">
	      <img src="img/foto1.jpeg">
	    </div>
	    <button class="ui button orange">Faculdades</button>
	  </div>

	    <div class="card">
	    <div class="image">
	      <img src="img/foto1.jpeg">
	    </div>
	    <button class="ui button orange">Sobre Nós</button>
	  </div>
	</div>


</head>
<body>




</body>
</html>

