<!DOCTYPE html>
<html>
<head>
  <title></title>
  <script type="text/javascript" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>
  <link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  <link rel="stylesheet" type="text/css" href="css/estilo.css">
  <link rel="stylesheet" type="text/css" href="../dist/components/message.css">
  <script src="assets/library/jquery.min.js"></script>
  <script src="../dist/components/form.js"></script>
  <script src="../dist/components/transition.js"></script>
  <script type="text/javascript">

    $('.ui.dropdown')
      .dropdown();
  </script>

   <script>
  $(document)
    .ready(function() {

      // fix menu when passed
      $('.masthead')
        .visibility({
          once: false,
          onBottomPassed: function() {
            $('.fixed.menu').transition('fade in');
          },
          onBottomPassedReverse: function() {
            $('.fixed.menu').transition('fade out');
          }
        })
      ;

      // create sidebar and attach to menu open
      $('.ui.sidebar')
        .sidebar('attach events', '.toc.item')
      ;

    })
  ;
  </script>

  <!-- Page Contents -->
<div class="pusher">
  <div href="img\fundo.jpeg" class="ui inverted vertical masthead center aligned segment cor1" >

    <div class="ui container cor2">
      <div class="ui large secondary inverted pointing menu cor2">
        <a class="toc item">
          <i class="sidebar icon"></i>
        </a>
        <a class="active item black">Home</a>
        <a class="item">Cadastro</a>
        <a class="item">Cursos</a>
        <a class="item inverted">Faculdades</a>
        <div class="right item">
          <a href="login.php" class="ui inverted button">Log in</a>
          <a href="cadastro.php" class="ui inverted button">Sign Up</a>
        </div>
      </div>
    </div>


      <div class="coluna_cad_dir"></div>
      <div class="barra_sup_login"></div>
      <div class="coluna_cad">
      <div class="coluna_cad2">

      <form class="ui form">
  <h3 class="ui dividing header">Edite suas Informações</h3>
  <div class="field">
    <label>Nome</label>
    <div class="two fields">
      <div class="field">
        <input type="text" name="shipping[first-name]" value="Primeiro Nome">
      </div>
      <div class="field">
        <input type="text" name="shipping[last-name]" value="Sobrenome">
      </div>
    </div>
  </div>

  <h4 class="ui dividing header">Email</h4>
  <div class="field">
        <div class="field">
          <div class="ui input">
            <input type="text" name="email" value="Seu Email">
          </div>
        </div>
  </div>
  <div class="two fields">
  </div>
  <h4 class="ui dividing header">Data de Nascimento</h4>
  <div class="fields">
    <div class="three wide field">
    </div>
    <div class="three wide field">

      <input type="text" name="dia" maxlength="3" value="Dia">
    </div>
    <div class="six wide field">

      <div class="two fields">
        <div class="field">
          <select class="ui fluid search dropdown" name="mes">
            <option value="">Mês</option>
            <option value="1">Janeiro</option>
            <option value="2">Fevereiro</option>
            <option value="3">Março</option>
            <option value="4">Abril</option>
            <option value="5">Maio</option>
            <option value="6">Junho</option>
            <option value="7">Julho</option>
            <option value="8">Agosto</option>
            <option value="9">Setembro</option>
            <option value="10">Outubro</option>
            <option value="11">Novembro</option>
            <option value="12">Dezembro</option>
          </select>
        </div>
        <div class="field">
          <input type="text" name="ano" maxlength="4" value="Ano">
        </div>
      </div>
    </div>
  </div>

   <h4 class="ui dividing header">Imagem de Perfil</h4>
        <div class="field">
          <div class="ui input">
            <input type="file" src="" name="image" value="Inserir Imagem">
          </div>
        </div>

   <h4 class="ui dividing header">Sua senha</h4>
  <div class="field">
      <div class="ui input">
        <input type="password" name="password" value="Senha">
    </div>
  </div>


  <div class="ui button" tabindex="0">Salvar</div>
</form>
</div>
</div>
