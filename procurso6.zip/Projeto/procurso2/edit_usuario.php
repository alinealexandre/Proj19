<?php 
include 'cabecalho.php';
//print_r($_SESSION['logado']);
?>

      <div class="coluna_cad_dir"></div>
      <div class="barra_sup_login"></div>
      <div class="coluna_edit_usu">
      <div class="coluna_cad2">

      <form method="post" action='controler.php?acao=editar' class="ui form">
      <input type="hidden" name="id_usuario" value="<?php echo $_SESSION['logado']['id_usuario']; ?>" requerid>
  <h3 class="ui dividing header" id="cor4">Edite suas Informações</h3>
  <div class="field">
    <label id="cor4">Nome</label>
    <div class="two fields">
      <div class="field">
        <input type="text" name="nome" value="<?php echo $_SESSION['logado']['nome']; ?>" requerid>
      </div>
      <div class="field">
        <input type="text" name="sobrenome" value="<?php echo $_SESSION['logado']['sobrenome']; ?>" requerid>
      </div>
    </div>
  </div>

  <h4 class="ui dividing header" id="cor4">Email</h4>
  <div class="field">
        <div class="field">
          <div class="ui input">
            <input type="text" name="email" value="<?php echo $_SESSION['logado']['email']; ?>" requerid>
          </div>
        </div>
  </div>
  <div class="two fields">
  </div>
  <h4 class="ui dividing header" id="cor4">Data de Nascimento</h4>

      <input type="date" name="data_nasc" value="<?php echo $_SESSION['logado']['data_nasc']; ?>" requerid>

   <h4 class="ui dividing header" id="cor4">Imagem de Perfil</h4>
        <div class="field">
          <div class="ui input">
            <input type="file" src="" name="image" value="Inserir Imagem">
          </div>
        </div>

   <h4 class="ui dividing header" id="cor4">Sua senha</h4>
  <div class="field">
      <div class="ui input">
        <input type="text" name="password" value="<?php echo $_SESSION['logado']['senha']; ?>" requerid>
    </div>
  </div>

  <input type="submit" class="ui button botao_enviar orange" value="Salvar">
</form>
</div>
</div>
 