<?php include 'cabecalho.php'?>


<div class="espaco_perfil">
    <div class="ui centered card">
      <div class="image">
        <img src="img/foto1.jpeg">
      </div>
      <div class="content">
        <a class="header">Aline</a>
        <div class="meta">
        </div>
        <div class="description">
          
        </div>
        <div class="ui list">
            <div class="item">
              <i class="user icon"></i>
              <div class="content">
                <a class="header" id="letra">Aline Silva Sauro</a>
              </div>
            </div>
            <div class="item">
              <i class="birthday cake icon"></i>
              <div class="content">
                <a class="header" id="letra">19/04/1990</a>
              </div>
            </div>
            <div class="item">
              <i class="edit icon"></i>
              <div class="content">
                <a href="edit_usuario.php" class="header">Editar Informações</a>
              </div>
            </div>
            <div class="item">
              <i class="trash alternate icon"></i>
              <div class="content">
                <a class="header">Excluir Conta</a>
              </div>
            </div>

        </div>
      </div>
    </div>
</div>

<div class="espaco_favoritos">

  <h1 class="ui dividing centered header">Favoritados</h1>
  <h2 class="ui dividing centered header">Cursos</h2>
    <div class="ui three column grid">
      <div class="column">
        <div class="ui fluid card ">
          <div class="image " >
             <img src="img/foto1.jpeg">
          </div>
          <div class="content">
            <a class="header">Geografia</a>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="ui fluid card">
          <div class="image">
            <img src="img/foto1.jpeg">
          </div>
          <div class="content">
            <a class="header">Ciências Sociais</a>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="ui fluid card">
          <div class="image">
            <img src="img/foto1.jpeg">
          </div>
          <div class="content">
            <a class="header">Agronomia</a>
          </div>
        </div>
      </div>
    </div>

  <h2 class="ui dividing centered header">Faculdades</h2>
    <div class="ui three column grid">
      <div class="column">
        <div class="ui fluid card">
          <div class="image">
            <img src="img/foto1.jpeg">
          </div>
          <div class="content">
            <a class="header">UFSC - Joinville</a>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="ui fluid card">
          <div class="image">
            <img src="img/foto1.jpeg">
          </div>
          <div class="content">
            <a class="header">UFFS - Chapecó</a>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="ui fluid card">
          <div class="image">
            <img src="img/foto1.jpeg">
          </div>
          <div class="content">
            <a class="header">UFSC - Florianópolis</a>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="ui fluid card">
          <div class="image">
            <img src="img/foto1.jpeg">
          </div>
          <div class="content">
            <a class="header">UFSC - Blumenau</a>
          </div>
        </div>
      </div>
    </div>



</div>
</div>
</body>

 <footer>
        <center class="footer">
      <i class="fa fa-facebook icones_footer"></i>
        <i class="fa fa-twitter icones_footer" ></i>
        <i class="fa fa-dribbble icones_footer"></i>
        </center>
</footer>

</html>



