<?php

class Usuario{
	private $id_usuario;
	public $nome;
	public $sobrenome;
	public $email;
	public $datanasc;
	public $senha;
	public $tipo_usuario;
	public $ftperfil;

	public function login(){
		
	}

}

