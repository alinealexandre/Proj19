<?php include 'cabecalho.php'?>


      <div class="coluna_cad_dir"></div>
      <div class="barra_sup_login"></div>
      <div class="coluna_edit_usu">
      <div class="coluna_cad2">

      <form class="ui form">
  <h3 class="ui dividing header" id="cor4">Edite suas Informações</h3>
  <div class="field">
    <label id="cor4">Nome</label>
    <div class="two fields">
      <div class="field">
        <input type="text" name="shipping[first-name]" value="Primeiro Nome">
      </div>
      <div class="field">
        <input type="text" name="shipping[last-name]" value="Sobrenome">
      </div>
    </div>
  </div>

  <h4 class="ui dividing header" id="cor4">Email</h4>
  <div class="field">
        <div class="field">
          <div class="ui input">
            <input type="text" name="email" value="Seu Email">
          </div>
        </div>
  </div>
  <div class="two fields">
  </div>
  <h4 class="ui dividing header" id="cor4">Data de Nascimento</h4>
  <div class="fields">
    <div class="three wide field">
    </div>
    <div class="three wide field">

      <input type="text" name="dia" maxlength="3" value="Dia">
    </div>
    <div class="six wide field">

      <div class="two fields">
        <div class="field">
          <select class="ui fluid search dropdown" name="mes">
            <option value="">Mês</option>
            <option value="1">Janeiro</option>
            <option value="2">Fevereiro</option>
            <option value="3">Março</option>
            <option value="4">Abril</option>
            <option value="5">Maio</option>
            <option value="6">Junho</option>
            <option value="7">Julho</option>
            <option value="8">Agosto</option>
            <option value="9">Setembro</option>
            <option value="10">Outubro</option>
            <option value="11">Novembro</option>
            <option value="12">Dezembro</option>
          </select>
        </div>
        <div class="field">
          <input type="text" name="ano" maxlength="4" value="Ano">
        </div>
      </div>
    </div>
  </div>

   <h4 class="ui dividing header" id="cor4">Imagem de Perfil</h4>
        <div class="field">
          <div class="ui input">
            <input type="file" src="" name="image" value="Inserir Imagem">
          </div>
        </div>

   <h4 class="ui dividing header" id="cor4">Sua senha</h4>
  <div class="field">
      <div class="ui input">
        <input type="password" name="password" value="Senha">
    </div>
  </div>


  <div class="ui button botao_enviar orange" tabindex="0">Salvar</div>
</form>
</div>
</div>
