<?php 
include 'cabecalho.php';
?>

<!-- Page Contents -->
<div class="pusher">
<div class="ui inverted vertical masthead center aligned segment cor1" href="img\fundo.jpeg">
    <div class="ui text container">
      <h1 class="ui inverted header">
        Procurso
      </h1>
      <h2>Encontre o curso e a faculdade ideal para você.</h2>
      <div class="ui search large">
      <div class="ui icon input">
        <input class="prompt" type="text" placeholder="Pesquisar...">
        <i class="search icon "></i>
      </div>
      <div class="results"></div>
    </div>
    </div>
      <a href="cadastro_curso.php"> cadastre um curso aqui</a>
      <br>
      <a href="cadastro_universidade.php"> cadastre uma universidade aqui </a>
  </div>
      
</div>


