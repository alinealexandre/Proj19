<?php
include 'class.php';
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
  <script type="text/javascript" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>
  <link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  <link rel="stylesheet" type="text/css" href="css/estilo.css">
  <link rel="stylesheet" type="text/css" href="../dist/components/message.css">
  <script src="assets/library/jquery.min.js"></script>
  <script src="../dist/components/form.js"></script>
  <script src="../dist/components/transition.js"></script>
  <script type="text/javascript">


    $('.ui.dropdown')
      .dropdown();
  </script>

   <script>
  $(document)
    .ready(function() {

      // fix menu when passed
      $('.masthead')
        .visibility({
          once: false,
          onBottomPassed: function() {
            $('.fixed.menu').transition('fade in');
          },
          onBottomPassedReverse: function() {
            $('.fixed.menu').transition('fade out');
          }
        })
      ;

      // create sidebar and attach to menu open
      $('.ui.sidebar')
        .sidebar('attach events', '.toc.item')
      ;

    })
  ;
  </script>
  <script>
  $(document)
    .ready(function() {
      $('.ui.form')
        .form({
          fields: {
            email: {
              identifier  : 'email',
              rules: [
                {
                  type   : 'empty',
                  prompt : 'Coloque seu email'
                },
                {
                  type   : 'email',
                  prompt : 'Coloque um email válido'
                }
              ]
            },
            password: {
              identifier  : 'password',
              rules: [
                {
                  type   : 'empty',
                  prompt : 'Coloque sua senha'
                },
                {
                  type   : 'length[6]',
                  prompt : 'Senha invalida'
                }
              ]
            }
          }
        })
      ;
    })
  ;
  </script>
<nav>
                    <div class="ui horizontal segments menu menu_edit">
                      <a href="index.php" class="active item" id="letra_menu">
                        Home
                      </a>
                      <a class="item" id="letra_menu">
                        Cursos
                      </a>
                      <a class="item" id="letra_menu">
                        Faculdades
                      </a>
                      <div class="logo_menu">
                        <img src="img/logo_temporaria.png" id="logo_logo">
                      </div>
                      <div class="right menu">
                      <?php
  if(isset($_SESSION['logado'])){
    echo "<a href='usuario.php'><button class='ui button yellow'>".$_SESSION['logado']['nome']."</button></a>";
   ?> 
  <a href="controler.php?acao=logout" class="ui inverted button">Log out</a>
  <?php
  }else{
    ?>

    <a href="login.php" class="ui button yellow">Log in</a>
    <a href="cadastro.php" class="ui inverted button">Sign Up</a>
        <?php
  }
?>

                      </div>
                    </div>
</nav>


